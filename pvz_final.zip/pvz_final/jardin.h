
#ifndef jardin_h
#define jardin_h

#include "zombies.h"

int **crearJardin(int *filas, int *columnas);

int **leerJardin(
    const char *nombreArchivo,
    int *filas,
    int *columnas
);

void imprimirMatriz(int **jardin, int *filas, int *columnas);


void liberarJardin(int **jardin, int *filas);

#endif

