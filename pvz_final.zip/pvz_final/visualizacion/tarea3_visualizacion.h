#ifndef TAREA3_VISUALIZACION_H
#define TAREA3_VISUALIZACION_H

#include "../estructuras.h"

#define PROYECTIL_NORMAL 0
#define PROYECTIL_FUEGO 1
#define PROYECTIL_GATO 2

void iniciarVisualizacion(void);

int debeCerrarVisualizacion(void);

void comenzarFrameVisualizacion(void);

void terminarFrameVisualizacion(void);

void cerrarVisualizacion(void);

void dibujarTerreno(void);

void dibujarDecoracion(void);

void dibujarArbusto(void);
void dibujarEstadoPartida(int oleada, int totalOleadas, int zombiesActivos, int zombiesPendientes, int tiempoRestante, int enPreparacion, int entreOleadas);
void dibujarCortacespedes(int cortacesped[], int filas);
int dibujarMenuPrincipal(void);
int dibujarInstrucciones(void);
int dibujarResultadoPartida(int gano);
void reiniciarElementosVisuales(void);

void dibujarTienda(int soles, int tiempoPreparacion);

void actualizarSeleccionTienda(void);

int obtenerPlantaSeleccionada(void);

void limpiarSeleccionTienda(void);

int obtenerCasillaClickeada(int *fila, int *columna);

void dibujarPlantas(int **jardin, int filas, int columnas);

void dibujarSoles(Sol soles[], int cantidadSoles);

void dibujarZombies(Zombie zombies[], int cantidadZombies);

void crearProyectil(int fila, int columna, int tipo);

void actualizarProyectiles(Zombie zombies[], int cantidadZombies);

void dibujarProyectiles(void);

#endif
