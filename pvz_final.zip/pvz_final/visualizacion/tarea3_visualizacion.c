
#include <stdlib.h>
#include "raylib.h"
#include "tarea3_visualizacion.h"
#include <stdio.h>

// Dimensiones del jardin.
#define FILAS 5
#define COLUMNAS 9

// Tamaño de cada casilla.
#define ANCHO_CELDA 80
#define ALTO_CELDA 80

// Posicion inicial del jardin.
#define INICIO_X 170
#define INICIO_Y 150
#define INICIO_FONDO_Y 100

// Texturas del terreno.
static Texture2D pastoClaro[3];
static Texture2D pastoOscuro[3];
static Texture2D pastoFondo;
static Texture2D valla;
static Texture2D arbol;
static Texture2D arbusto1;
static Texture2D arbusto2;
static Texture2D arbusto3;
static Texture2D arbusto4;
static Texture2D arbusto4v2;
static Texture2D lozasCasa[4];
static Texture2D lozasAbajo[4];
static Texture2D casa;
static Texture2D podadora;
static Texture2D fondoMenu;

// Texturas de las plantas.
static Texture2D girasol;
static Texture2D sol;
static Texture2D lanzaguisantes;
static Texture2D nuez;
static Texture2D catSpikes;
static Texture2D lanzaguisantesFuego;
static Texture2D nuezReforzada;

// Planta seleccionada en la tienda.
static int plantaSeleccionada = -1;

// Estructura de proyectiles
#define MAX_PROYECTILES 100

typedef struct {
    float x;
    float y;
    int fila;
    int tipo;
    int activo;
} Proyectil;

//Texturas de los proyectiles.
static Texture2D proyectil;
static Texture2D proyectilFuego;
static Texture2D proyectilGato;

static Proyectil proyectiles[MAX_PROYECTILES];

// Crea un proyectil en la posición de la casilla indicada y registra su tipo para actualizarlo y dibujarlo.
void crearProyectil(int fila, int columna, int tipo) {
    for (int i = 0; i < MAX_PROYECTILES; i++) {
        if (!proyectiles[i].activo) {
            proyectiles[i].x = INICIO_X + columna * ANCHO_CELDA + 55;
            proyectiles[i].y = INICIO_Y + fila * ALTO_CELDA + 30;
            proyectiles[i].fila = fila;
            proyectiles[i].tipo = tipo;
            proyectiles[i].activo = 1;
            break;
        }
    }
}


// Avanza los proyectiles, comprueba sus impactos contra zombies y desactiva los que ya terminaron su recorrido.
void actualizarProyectiles(Zombie zombies[], int cantidadZombies) {
    for (int i = 0; i < MAX_PROYECTILES; i++) {

        if (!proyectiles[i].activo) {
            continue;
        }

        if(proyectiles[i].tipo == PROYECTIL_GATO){
            proyectiles[i].x += 12;
        }
        else{
            proyectiles[i].x += 5;
        }

        if(proyectiles[i].tipo != PROYECTIL_GATO){
            for (int j = 0; j < cantidadZombies; j++) {

                if (!zombies[j].activo ||
                    zombies[j].fila != proyectiles[i].fila) {
                    continue;
                }

                int zombieX = INICIO_X +
                            zombies[j].columna * ANCHO_CELDA;

                if (proyectiles[i].x + 24 >= zombieX + 8 &&
                    proyectiles[i].x <= zombieX + 72) {

                    proyectiles[i].activo = 0;
                    break;
                }
            }
        }

        if (proyectiles[i].x > INICIO_X + 9 * ANCHO_CELDA) {
            proyectiles[i].activo = 0;
        }
    }
}

// Dibuja en pantalla los proyectiles activos usando el sprite correspondiente a su tipo.
void dibujarProyectiles(void) {
    for (int i = 0; i < MAX_PROYECTILES; i++) {
        if (!proyectiles[i].activo) {
            continue;
        }

        Texture2D textura;

    if (proyectiles[i].tipo == PROYECTIL_FUEGO) {
        textura = proyectilFuego;
    }
    else if (proyectiles[i].tipo == PROYECTIL_GATO) {
        textura = proyectilGato;
    }
    else {
        textura = proyectil;
    }

       Rectangle destino = {
        proyectiles[i].x,
        proyectiles[i].y,
        24,
        24
    };

    DrawTexturePro(
        textura,
        (Rectangle){0, 0, textura.width, textura.height},
        destino,
        (Vector2){0, 0},
        0,
        WHITE
    ); 
    }
}


//Texturas de los zombies
static Texture2D zombie;
static Texture2D zombieAbanderado;
static Texture2D cono;
static Texture2D balde;


// Distribucion de las texturas.
static int terreno[FILAS][COLUMNAS];

// Inicializa la ventana, las texturas, los sonidos y los recursos gráficos que utiliza la interfaz.
void iniciarVisualizacion(void) {

    InitWindow(900, 600, "Plants vs Zombies");
    SetTargetFPS(60);

    // Fondo personalizado del menu principal.
    fondoMenu = LoadTexture(
        "visualizacion/recursos/ambiente/fondo_menu.png"
    );
    SetTextureFilter(fondoMenu, TEXTURE_FILTER_POINT);

    //cargar el fondo del jardin
    pastoFondo = LoadTexture(
        "visualizacion/recursos/ambiente/pasto_fondo.png"
    );

    SetTextureFilter(pastoFondo, TEXTURE_FILTER_POINT);

    valla = LoadTexture(
        "visualizacion/recursos/ambiente/valla.png"
    );

    SetTextureFilter(valla, TEXTURE_FILTER_POINT);

    // Cargar los elementos decorativos.
    arbol = LoadTexture("visualizacion/recursos/ambiente/arbol.png");
    arbusto1 = LoadTexture("visualizacion/recursos/ambiente/arbusto1.png");
    arbusto2 = LoadTexture("visualizacion/recursos/ambiente/arbusto2.png");
    arbusto3 = LoadTexture("visualizacion/recursos/ambiente/arbusto3.png");
    arbusto4 = LoadTexture("visualizacion/recursos/ambiente/arbusto4.png");
    arbusto4v2 = LoadTexture("visualizacion/recursos/ambiente/arbusto_4.png");

    // Filtro para conservar el pixel art.
    SetTextureFilter(arbol, TEXTURE_FILTER_POINT);
    SetTextureFilter(arbusto1, TEXTURE_FILTER_POINT);
    SetTextureFilter(arbusto2, TEXTURE_FILTER_POINT);
    SetTextureFilter(arbusto3, TEXTURE_FILTER_POINT);
    SetTextureFilter(arbusto4, TEXTURE_FILTER_POINT);
    SetTextureFilter(arbusto4v2, TEXTURE_FILTER_POINT);

    //mas elementos decorativos, las lozas.
    lozasCasa[0] = LoadTexture("visualizacion/recursos/ambiente/Lozapiedra.png");
    lozasCasa[1] = LoadTexture("visualizacion/recursos/ambiente/Lozapiedra 2.png");
    lozasCasa[2] = LoadTexture("visualizacion/recursos/ambiente/Lozapiedra 3.png");
    lozasCasa[3] = LoadTexture("visualizacion/recursos/ambiente/Lozapiedra 4.png");
    
    //se agrega el filtro.
    for (int i = 0; i < 4; i++) {
            SetTextureFilter(lozasCasa[i], TEXTURE_FILTER_POINT);
        }

    //mas lozas.
    lozasAbajo[0] = LoadTexture("visualizacion/recursos/ambiente/Lozapiedra horizontal .png");
    lozasAbajo[1] = LoadTexture("visualizacion/recursos/ambiente/Lozapiedra 2 horizontal .png");
    lozasAbajo[2] = LoadTexture("visualizacion/recursos/ambiente/Lozapiedra 3 horizontal .png");
    lozasAbajo[3] = LoadTexture("visualizacion/recursos/ambiente/Lozapiedra 4 horizontal .png");

    //se agrega el filtro.
    for (int i = 0; i < 4; i++) {
        SetTextureFilter(lozasAbajo[i], TEXTURE_FILTER_POINT);
    }

    casa = LoadTexture("visualizacion/recursos/ambiente/Casa.png");
SetTextureFilter(casa, TEXTURE_FILTER_POINT);

    // Podadora para cada fila del jardin.
    podadora = LoadTexture("visualizacion/recursos/plantas/Podadora.png");
    SetTextureFilter(podadora, TEXTURE_FILTER_POINT);

    
    // Cargar las tres texturas de pasto claro.
    pastoClaro[0] = LoadTexture(
        "visualizacion/recursos/terreno/pasto_claro.png"
    );

    pastoClaro[1] = LoadTexture(
        "visualizacion/recursos/terreno/pasto_claro_2.png"
    );

    pastoClaro[2] = LoadTexture(
        "visualizacion/recursos/terreno/pasto_claro_3.png"
    );

    // Cargar las tres texturas de pasto oscuro.
    pastoOscuro[0] = LoadTexture(
        "visualizacion/recursos/terreno/pasto_oscuro.png"
    );

    pastoOscuro[1] = LoadTexture(
        "visualizacion/recursos/terreno/pasto_oscuro_2.png"
    );

    pastoOscuro[2] = LoadTexture(
        "visualizacion/recursos/terreno/pasto_oscuro_3.png"
    );

    //cargar las plantas.
    girasol = LoadTexture(
        "visualizacion/recursos/plantas/girasol.png"
    );
    sol = LoadTexture("visualizacion/recursos/plantas/sol.png");
    SetTextureFilter(sol, TEXTURE_FILTER_POINT);
    lanzaguisantes = LoadTexture(
        "visualizacion/recursos/plantas/lanzaguisantes.png"
    );
    nuez = LoadTexture(
        "visualizacion/recursos/plantas/nuez.png"
    );
    catSpikes = LoadTexture(
        "visualizacion/recursos/plantas/cat_spikes.png"
    );
    lanzaguisantesFuego = LoadTexture(
        "visualizacion/recursos/plantas/lanzaguisantes_fuego.png"
    );
    nuezReforzada = LoadTexture(
        "visualizacion/recursos/plantas/nuez_reforzada.png"
    );

    //cargar proyectiles
    proyectil = LoadTexture(
        "visualizacion/recursos/proyectiles/proyectil.png"
    );
    proyectilFuego = LoadTexture(
        "visualizacion/recursos/proyectiles/proyectil_fuego.png"
    );
    proyectilGato = LoadTexture(
        "visualizacion/recursos/proyectiles/proyectil_gato.png"
    );

    //cargar los zombies
    zombie = LoadTexture("visualizacion/recursos/zombies/zombie.png");
    zombieAbanderado = LoadTexture("visualizacion/recursos/zombies/zombie_abanderado.png");
    cono = LoadTexture("visualizacion/recursos/zombies/cono.png");
    balde = LoadTexture("visualizacion/recursos/zombies/balde.png");

    // Conservamos los pixeles originales del pixel art con el filtro.
    for (int i = 0; i < 3; i++) {
        SetTextureFilter(pastoClaro[i], TEXTURE_FILTER_POINT);
        SetTextureFilter(pastoOscuro[i], TEXTURE_FILTER_POINT);
    }

    //filtro de las plantas
    SetTextureFilter(girasol, TEXTURE_FILTER_POINT);
    SetTextureFilter(lanzaguisantes, TEXTURE_FILTER_POINT);
    SetTextureFilter(nuez, TEXTURE_FILTER_POINT);
    SetTextureFilter(catSpikes, TEXTURE_FILTER_POINT);
    SetTextureFilter(lanzaguisantesFuego, TEXTURE_FILTER_POINT);
    SetTextureFilter(nuezReforzada, TEXTURE_FILTER_POINT);


    //filtro de los zombies
    SetTextureFilter(zombie, TEXTURE_FILTER_POINT);
    SetTextureFilter(zombieAbanderado, TEXTURE_FILTER_POINT);
    SetTextureFilter(cono, TEXTURE_FILTER_POINT);
    SetTextureFilter(balde, TEXTURE_FILTER_POINT);

    //filtros de los proyectiles
    SetTextureFilter(proyectil, TEXTURE_FILTER_POINT);
    SetTextureFilter(proyectilFuego, TEXTURE_FILTER_POINT);
    SetTextureFilter(proyectilGato, TEXTURE_FILTER_POINT);

    // Elegimos una variante aleatoria para cada casilla.
    for (int i = 0; i < FILAS; i++) {
        for (int j = 0; j < COLUMNAS; j++) {
            terreno[i][j] = rand() % 3;
        }
    }
}

// Indica si el usuario solicitó cerrar la ventana del juego.
int debeCerrarVisualizacion(void) {
    return WindowShouldClose();
}

// Prepara el inicio del frame de dibujo y limpia la pantalla con el color de fondo.
void comenzarFrameVisualizacion(void) {
    BeginDrawing();
    ClearBackground(SKYBLUE);
}

// Dibuja las casillas del jardín usando las variantes de textura del terreno.
void dibujarTerreno(void) {
    // Dibujamos el pasto alrededor del tablero.
    for (int y = INICIO_FONDO_Y + 32; y < 600; y += ALTO_CELDA) {

        for (int x = 0; x < 900; x += ANCHO_CELDA) {

            DrawTexturePro(
                pastoFondo,
                (Rectangle){
                    0, 0,
                    pastoFondo.width,
                    pastoFondo.height
                },
                (Rectangle){
                    x, y,
                    ANCHO_CELDA,
                    ALTO_CELDA
                },
                (Vector2){0, 0},
                0,
                WHITE
            );
        }
    }

    for (int i = 0; i < FILAS; i++) {

        for (int j = 0; j < COLUMNAS; j++) {

            int x = INICIO_X + j * ANCHO_CELDA;
            int y = INICIO_Y + i * ALTO_CELDA;

            Texture2D textura;

            // Alternamos pasto claro y oscuro.
            if ((i + j) % 2 == 0) {
                textura = pastoClaro[terreno[i][j]];
            } else {
                textura = pastoOscuro[terreno[i][j]];
            }

            Rectangle origen = {
                0, 0,
                (float)textura.width,
                (float)textura.height
            };

            Rectangle destino = {
                (float)x,
                (float)y,
                ANCHO_CELDA,
                ALTO_CELDA
            };

            DrawTexturePro(
                textura,
                origen,
                destino,
                (Vector2){0, 0},
                0,
                WHITE
            );
        }
    }
}

// Dibuja los elementos decorativos del escenario, como la casa, la valla y la vegetación.
void dibujarDecoracion(void) {
    // Baldosas verticales del costado de la casa.
    for (int fila = 0; fila < 5; fila++) {
        for (int columna = 0; columna < 4; columna++) {

            int variante = (fila + columna) % 4;

            DrawTexturePro(
                lozasCasa[variante],
                (Rectangle){0, 0, lozasCasa[variante].width, lozasCasa[variante].height},
                (Rectangle){-20 + columna * 45, 190 + fila *75, 60, 80},
                (Vector2){0, 0}, 0, WHITE
            );
        }
    }

    // Baldosas horizontales de la parte inferior.
    DrawTexturePro(lozasAbajo[0],
        (Rectangle){0, 0, lozasAbajo[0].width, lozasAbajo[0].height},
        (Rectangle){150+30, 545, 65, 45},
        (Vector2){0, 0}, 0, WHITE);

    DrawTexturePro(lozasAbajo[2],
        (Rectangle){0, 0, lozasAbajo[2].width, lozasAbajo[2].height},
        (Rectangle){260+30, 550, 65, 45},
        (Vector2){0, 0}, 0, WHITE);

    DrawTexturePro(lozasAbajo[1],
        (Rectangle){0, 0, lozasAbajo[1].width, lozasAbajo[1].height},
        (Rectangle){380+30, 540, 65, 45},
        (Vector2){0, 0}, 0, WHITE);

    DrawTexturePro(lozasAbajo[3],
        (Rectangle){0, 0, lozasAbajo[3].width, lozasAbajo[3].height},
        (Rectangle){500+30, 550, 65, 45},
        (Vector2){0, 0}, 0, WHITE);

    DrawTexturePro(lozasAbajo[0],
        (Rectangle){0, 0, lozasAbajo[0].width, lozasAbajo[0].height},
        (Rectangle){620+30, 545, 65, 45},
        (Vector2){0, 0}, 0, WHITE);


    // Arbusto 2: detras de la valla.
    for (int x = 0; x < 900; x += 90) {
        DrawTexturePro(
            arbusto2,
            (Rectangle){0, 0, arbusto2.width, arbusto2.height},
            (Rectangle){x, 65, 130, 90},
            (Vector2){0, 0}, 0, WHITE
        );
    }

    // Vallas.
    for (int x = 0; x < 900; x += 64) {
        DrawTexturePro(
            valla,
            (Rectangle){0, 0, valla.width, valla.height},
            (Rectangle){x, 80, 64, 64},
            (Vector2){0, 0}, 0, WHITE
        );
    }

    // Arbol: delante de las vallas.
    DrawTexturePro(
        arbol,
        (Rectangle){0, 0, arbol.width, arbol.height},
        (Rectangle){-10, 5, 175, 175},
        (Vector2){0, 0}, 0, WHITE
    );

    // Arbusto 1: al lado del arbol.
    DrawTexturePro(
        arbusto1,
        (Rectangle){0, 0, arbusto1.width, arbusto1.height},
        (Rectangle){40, 120, 115, 85},
        (Vector2){0, 0}, 0, WHITE
    );

    // Arbusto 3: delante de la valla.
    DrawTexturePro(
        arbusto3,
        (Rectangle){0, 0, arbusto3.width, arbusto3.height},
        (Rectangle){690, 90, 105, 75},
        (Vector2){0, 0}, 0, WHITE
    );

    // Arbusto 4: esquina inferior izquierda.
    DrawTexturePro(
        arbusto4,
        (Rectangle){0, 0, arbusto4.width, arbusto4.height},
        (Rectangle){0, 460, 145, 145},
        (Vector2){0, 0}, 0, WHITE
    );


    // Casa.
    DrawTexturePro(
        casa,
        (Rectangle){0, 0, casa.width, casa.height},
        (Rectangle){-195, 120, 440, 440},
        (Vector2){0, 0}, 0, WHITE
    );
}

// Dibuja un arbusto decorativo por separado ya que se necesita que este vaya por
//encima de los zombies a diferencia de la funcion de las otras decoraciones
void dibujarArbusto(void){
    //arbusto 4 v2: la otra esquina
    DrawTexturePro(
        arbusto4v2,
        (Rectangle){0, 0, arbusto4.width, arbusto4.height},
        (Rectangle){755, 460, 145, 145},
        (Vector2){0, 0}, 0, WHITE
    );
}

// Muestra la tienda, sus plantas, precios, soles disponibles y el tiempo de preparación.
void dibujarTienda(int soles, int tiempoPreparacion) {

    // Este dato se conserva en la interfaz por compatibilidad con el llamado actual.
    (void)tiempoPreparacion;

    // Fondo de la barra de la tienda.
    DrawRectangle(10, 10, 880, 80, DARKGREEN);
    DrawRectangleLines(10, 10, 880, 80, GOLD);

    // Contador de soles.
    DrawRectangle(18, 20, 85, 60, GOLD);
    DrawText("SOLES", 32, 25, 12, BLACK);

    char textoSoles[20];
    sprintf(textoSoles, "%d", soles);
    DrawText(textoSoles, 37, 45, 22, BLACK);

    // Imagenes y precios de las plantas.
    Texture2D plantas[] = {
        girasol,
        lanzaguisantes,
        nuez,
        catSpikes,
        lanzaguisantesFuego,
        nuezReforzada
    };

    int precios[] = {50, 100, 150, 125, 175, 200};

    const char *nombres[] = {
        "Girasol",
        "Lanzaguisantes",
        "Nuez",
        "Gato",
        "Lanzaguisantes",
        "Nuez"
    };

    for (int i = 0; i < 6; i++) {

        int x = 110 + i * 128;

        // Tarjeta de cada planta.
        DrawRectangle(x, 17, 120, 66, BEIGE);
        DrawRectangleLines(x, 17, 120, 66, BROWN);

        if (i == plantaSeleccionada) {
            DrawRectangleLinesEx(
                (Rectangle){x, 17, 120, 66},
                3,
                GOLD
            );
        }

        // Sprite de la planta.
        DrawTexturePro(
            plantas[i],
            (Rectangle){0, 0, plantas[i].width, plantas[i].height},
            (Rectangle){x + 5, 29, 40, 40},
            (Vector2){0, 0},
            0,
            WHITE
        );

        // Nombre y precio. Los nombres largos se muestran en dos líneas
        // para que no invadan la tarjeta de la planta siguiente.
        if (i == 3) {
            DrawText("Gato", x + 48, 26, 10, BLACK);
            DrawText("espinoso", x + 48, 38, 10, BLACK);
        } else if (i == 4) {
            DrawText("Lanzaguisantes", x + 37, 26, 9, BLACK);
            DrawText("de fuego", x + 48, 38, 10, BLACK);
        } else if (i == 5) {
            DrawText("Nuez", x + 48, 26, 10, BLACK);
            DrawText("reforzada", x + 48, 38, 10, BLACK);
        } else if (i == 1) {
            DrawText(nombres[i], x + 37, 30, 10, BLACK);
        } else {
            DrawText(nombres[i], x + 48, 30, 10, BLACK);
        }

        // El precio queda debajo del nombre, sin salirse de la tarjeta.
        char precio[20];
        sprintf(precio, "%d", precios[i]);

        DrawText(precio, x + 48, 57, 14, DARKGREEN);
    }
        
}


// Actualiza la selección de planta de la tienda según la interacción del mouse.
void actualizarSeleccionTienda(void) {

    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {

        Vector2 mouse = GetMousePosition();

        for (int i = 0; i < 6; i++) {

            int x = 110 + i * 128;

            if (mouse.x >= x && mouse.x <= x + 120 &&
                mouse.y >= 17 && mouse.y <= 83) {

                plantaSeleccionada = i;
                break;
            }
        }
    }
}

// Devuelve el tipo de planta seleccionado en la tienda.
int obtenerPlantaSeleccionada(void) {
    return plantaSeleccionada;
}

// Limpia la selección actual de la tienda al cancelar o reiniciar la compra.
void limpiarSeleccionTienda(void) {
    plantaSeleccionada = -1;
}


// Convierte la posición del clic en una fila y columna del jardín, si el clic ocurrió dentro del tablero.
int obtenerCasillaClickeada(int *fila, int *columna) {

    if (!IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
        return 0;
    }

    Vector2 mouse = GetMousePosition();

    if (mouse.x < INICIO_X ||
        mouse.x >= INICIO_X + COLUMNAS * ANCHO_CELDA ||
        mouse.y < INICIO_Y ||
        mouse.y >= INICIO_Y + FILAS * ALTO_CELDA) {
        return 0;
    }

    *columna = (int)(mouse.x - INICIO_X) / ANCHO_CELDA;
    *fila = (int)(mouse.y - INICIO_Y) / ALTO_CELDA;

    return 1;
}


// Dibuja los soles coleccionables sobre el jardin.
void dibujarSoles(Sol soles[], int cantidadSoles) {
    for (int i = 0; i < cantidadSoles; i++) {
        if (soles[i].activo) {
            DrawTexturePro(
                sol,
                (Rectangle){0, 0, (float)sol.width, (float)sol.height},
                (Rectangle){soles[i].x - 18, soles[i].y - 18, 36, 36},
                (Vector2){0, 0},
                0,
                WHITE
            );
        }
    }
}

// Dibuja las plantas presentes en la matriz del jardín según el código de cada casilla.
void dibujarPlantas(int **jardin, int filas, int columnas) {

    for (int i = 0; i < filas; i++) {

        for (int j = 0; j < columnas; j++) {

            int x = INICIO_X + j * ANCHO_CELDA;
            int y = INICIO_Y + i * ALTO_CELDA;

            Texture2D textura;

            switch (jardin[i][j]) {

                case 1:
                    textura = lanzaguisantes;
                    break;

                case 2:
                    textura = girasol;
                    break;

                case 3:
                    textura = nuez;
                    break;
               
                case 5:
                    textura = catSpikes;
                    break;
                
                case 6:
                    textura = lanzaguisantesFuego;
                    break;
                
                case 7:
                    textura = nuezReforzada;
                    break;

                default:
                    continue;
            }

            // Centrar la planta dentro de la casilla.
            Rectangle destino = {
                (float)x + 8,
                (float)y + 8,
                64,
                64
            };

            DrawTexturePro(
                textura,
                (Rectangle){
                    0, 0,
                    (float)textura.width,
                    (float)textura.height
                },
                destino,
                (Vector2){0, 0},
                0,
                WHITE
            );
        }
    }
}


// Dibuja los zombies activos en sus posiciones actuales y utiliza su sprite según el tipo.
void dibujarZombies(Zombie zombies[], int cantidadZombies) {

    for (int i = 0; i < cantidadZombies; i++) {

        if (!zombies[i].activo) {
            continue;
        }

        int x = INICIO_X + zombies[i].columna * ANCHO_CELDA;
        int y = INICIO_Y + zombies[i].fila * ALTO_CELDA;

        Texture2D cuerpo = zombie;

        switch (zombies[i].tipoZombie) {

            case ZOMBIE_NORMAL:
                cuerpo = zombie;
                break;

            case ZOMBIE_BANDERA:
                cuerpo = zombieAbanderado;
                break;

            case ZOMBIE_CONO:
                cuerpo = zombie;
                break;

            case ZOMBIE_CUBETA:
                cuerpo = zombie;
                break;
        }

        Rectangle destino = {
            (float)x + 8,
            (float)y + 8,
            64,
            64
        };

        DrawTexturePro(
            cuerpo,
            (Rectangle){0, 0, (float)cuerpo.width, (float)cuerpo.height},
            destino,
            (Vector2){0, 0},
            0,
            WHITE
        );

        // Accesorios sobre la cabeza.
        if (zombies[i].tipoZombie == ZOMBIE_CONO) {

        Rectangle destinoCono = {
            x + 16, y - 8, 48, 48
        };

        DrawTexturePro(cono,
            (Rectangle){0, 0, cono.width, cono.height},
            destinoCono,
            (Vector2){0, 0},
            0, WHITE);
    }   

    if (zombies[i].tipoZombie == ZOMBIE_CUBETA) {

        Rectangle destinoBalde = {
            x + 16, y - 2, 52, 52
        };

        DrawTexturePro(balde,
            (Rectangle){0, 0, balde.width, balde.height},
            destinoBalde,
            (Vector2){0, 0},
            0, WHITE);
    }
    }
}


// informacion de oleadas y estado general.
// Se ubica en la esquina inferior derecha para no tapar la tienda.
void dibujarEstadoPartida(int oleada, int totalOleadas, int zombiesActivos, int zombiesPendientes, int tiempoRestante, int enPreparacion, int entreOleadas) {
    DrawRectangle(590, 542, 300, 50, Fade(BLACK, 0.82f));
    DrawRectangleLines(590, 542, 300, 50, WHITE);
    DrawText(TextFormat("OLEADA: %d / %d", oleada, totalOleadas), 602, 547, 17, WHITE);
    DrawText(TextFormat("Zombies: %d activos | %d pendientes", zombiesActivos, zombiesPendientes), 602, 570, 12, WHITE);

    // El contador aparece una sola vez, en un recuadro inferior izquierdo.
    if (enPreparacion || entreOleadas) {
        const char *mensaje = enPreparacion ? "PREPARA TU JARDIN" : "SIGUIENTE OLEADA";
        DrawRectangle(10, 542, 280, 50, Fade(BLACK, 0.82f));
        DrawRectangleLines(10, 542, 280, 50, WHITE);
        DrawText(TextFormat("%s", mensaje), 22, 547, 15, YELLOW);
        DrawText(TextFormat("Comienza en: %d s", tiempoRestante), 22, 570, 14, WHITE);
    }
}

// Dibuja una podadora al inicio de cada fila.
// Si ya fue utilizada, se muestra atenuada.
void dibujarCortacespedes(int cortacesped[], int filas) {
    for (int i = 0; i < filas; i++) {
        float y = INICIO_Y + i * ALTO_CELDA - 20;
        Color tinte = cortacesped[i] ? WHITE : Fade(GRAY, 0.45f);

        DrawTexturePro(
            podadora,
            (Rectangle){0, 0, podadora.width, podadora.height},
            (Rectangle){98, y, 110, 110},
            (Vector2){0, 0},
            0,
            tinte
        );
    }
}


// Dibuja un boton pixelado y devuelve si el mouse esta encima.
static int dibujarBotonMenu(Rectangle area, const char *texto) {
    Vector2 mouse = GetMousePosition();
    int hover = CheckCollisionPointRec(mouse, area);

    DrawRectangleRec(area, hover ? (Color){75, 150, 75, 255}
                                  : (Color){48, 105, 55, 255});
    DrawRectangleLinesEx(area, 4, (Color){28, 55, 32, 255});
    DrawRectangle((int)area.x + 5, (int)area.y + 5,
                  (int)area.width - 10, 4, (Color){145, 195, 115, 255});

    int fontSize = 20;
    int ancho = MeasureText(texto, fontSize);
    DrawText(texto, (int)(area.x + (area.width - ancho) / 2),
             (int)(area.y + (area.height - fontSize) / 2),
             fontSize, RAYWHITE);
    return hover;
}

// Fondo compartido por el menu y las instrucciones.
static void dibujarFondoMenu(void) {
    DrawTexturePro(
        fondoMenu,
        (Rectangle){0, 0, (float)fondoMenu.width, (float)fondoMenu.height},
        (Rectangle){0, 0, 900, 600},
        (Vector2){0, 0},
        0,
        WHITE
    );
}

// Dibuja el menú inicial y devuelve la opción seleccionada por el usuario.
int dibujarMenuPrincipal(void) {
    dibujarFondoMenu();

    // El titulo y los personajes ya vienen incluidos en la imagen.
    // Deja los botones en el espacio verde central.
    int jugarHover = dibujarBotonMenu(
        (Rectangle){345, 330, 210, 52}, "JUGAR"
    );
    int instruccionesHover = dibujarBotonMenu(
        (Rectangle){325, 405, 250, 52}, "INSTRUCCIONES"
    );
    int salirHover = dibujarBotonMenu(
        (Rectangle){345, 480, 210, 52}, "SALIR"
    );

    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
        if (jugarHover) return 1;
        if (instruccionesHover) return 2;
        if (salirHover) return 3;
    }
    return 0;
}

// Muestra las instrucciones del juego y permite volver al menú principal.
int dibujarInstrucciones(void) {
    dibujarFondoMenu();

    // Panel semitransparente para mantener visible el fondo personalizado.
    DrawRectangle(105, 42, 690, 510, (Color){242, 232, 190, 245});
    DrawRectangleLinesEx((Rectangle){105, 42, 690, 510}, 5,
                         (Color){75, 65, 42, 255});

    const char *titulo = "COMO JUGAR";
    int ancho = MeasureText(titulo, 34);
    DrawText(titulo, (900 - ancho) / 2, 68, 34,
             (Color){45, 85, 42, 255});

    DrawText("OBJETIVO", 155, 140, 22, (Color){65, 105, 45, 255});
    DrawText("Defiende tu jardin y sobrevive a las 5 oleadas.", 155, 171, 18, DARKBROWN);
    DrawText("RECURSOS", 155, 215, 22, (Color){65, 105, 45, 255});
    DrawText("- Haz clic en los soles para recogerlos.", 155, 246, 18, DARKBROWN);
    DrawText("- Los girasoles generan soles automaticamente.", 155, 274, 18, DARKBROWN);
    DrawText("- Usa los soles para comprar plantas.", 155, 302, 18, DARKBROWN);
    DrawText("- Las podadoras eliminan a todos los zombis de una fila.", 155, 330, 17, DARKBROWN);
    DrawText("CONTROLES", 155, 365, 22, (Color){65, 105, 45, 255});
    DrawText("- Haz clic en una planta de la tienda para seleccionarla.", 155, 396, 17, DARKBROWN);
    DrawText("- Haz clic en una casilla vacia para colocarla.", 155, 423, 17, DARKBROWN);
    DrawText("- Haz clic sobre los soles para recogerlos.", 155, 450, 17, DARKBROWN);

    int volverHover = dibujarBotonMenu((Rectangle){350, 480, 200, 48}, "VOLVER");
    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && volverHover) return 1;
    if (IsKeyPressed(KEY_ESCAPE)) return 1;
    return 0;
}

// Muestra la pantalla de victoria o derrota y devuelve la acción elegida.
int dibujarResultadoPartida(int gano) {
    DrawRectangle(0, 0, 900, 600, Fade(BLACK, 0.78f));
    const char *titulo = gano ? "¡GANASTE!" : "¡PERDISTE!";
    const char *detalle = gano ? "Has defendido tu jardin" : "Los zombies llegaron a la casa";
    int ancho = MeasureText(titulo, 52);
    DrawText(titulo, (900 - ancho) / 2, 175, 52, gano ? GOLD : RED);
    ancho = MeasureText(detalle, 24);
    DrawText(detalle, (900 - ancho) / 2, 245, 24, WHITE);

    int repetirHover = dibujarBotonMenu((Rectangle){330, 325, 240, 55}, "JUGAR DE NUEVO");
    int menuHover = dibujarBotonMenu((Rectangle){350, 400, 200, 50}, "MENU PRINCIPAL");
    DrawText("ESC - Cerrar juego", 370, 490, 18, LIGHTGRAY);

    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
        if (repetirHover) return 1;
        if (menuHover) return 2;
    }
    if (IsKeyPressed(KEY_ESCAPE)) return 3;
    return 0;
}

// Restablece las selecciones y los elementos gráficos temporales para una nueva partida.
void reiniciarElementosVisuales(void) {
    plantaSeleccionada = -1;
    for (int i = 0; i < MAX_PROYECTILES; i++) {
        proyectiles[i].activo = 0;
    }
}

// Finaliza el frame actual de dibujo de Raylib.
void terminarFrameVisualizacion(void) {
    EndDrawing();
}

// Libera las texturas, sonidos y demás recursos gráficos antes de cerrar la ventana.
void cerrarVisualizacion(void) {

    // Liberar el fondo personalizado del menu.
    UnloadTexture(fondoMenu);

    // Liberar las texturas del terreno.
    for (int i = 0; i < 3; i++) {
        UnloadTexture(pastoClaro[i]);
        UnloadTexture(pastoOscuro[i]);
    }
    //liberar memoria del fondo
    UnloadTexture(pastoFondo);
    UnloadTexture(valla);
    UnloadTexture(arbol);
    UnloadTexture(arbusto1);
    UnloadTexture(arbusto2);
    UnloadTexture(arbusto3);
    UnloadTexture(arbusto4);
    UnloadTexture(arbusto4v2);
    for (int i = 0; i < 4; i++) {
        UnloadTexture(lozasCasa[i]);
    }
    for (int i = 0; i < 4; i++) {
        UnloadTexture(lozasAbajo[i]);
    }
    UnloadTexture(casa);
    UnloadTexture(podadora);

    //liberar la memoria utilizada por las imagenes
    UnloadTexture(girasol);
    UnloadTexture(sol);
    UnloadTexture(lanzaguisantes);
    UnloadTexture(nuez);
    UnloadTexture(catSpikes);
    UnloadTexture(lanzaguisantesFuego);
    UnloadTexture(nuezReforzada);

    //liberar memoria de los proyectiles
    UnloadTexture(proyectil);
    UnloadTexture(proyectilFuego);
    UnloadTexture(proyectilGato);

    CloseWindow();
}
