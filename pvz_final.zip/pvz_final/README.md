# Plants vs. Zombies — Pixel Version

Tarea Semestral - Programación de Computadores

## Integrantes

- Justine Huerta
- Krishna Victoriano
- Fabián Heredia

## Declaracion de uso de IA

- se declara el uso de IA como apoyo para las distintas tareas del proyecto, tanto logicas como visuales.

- En temas visuales solo se hace uso de IA para el diseño del titulo en el menu principal, todos los diseños de personajes y decoraciones son originales.

## Requisitos de ejecución

- Tener instalado GCC.
- Tener instalada la biblioteca Raylib.
- Tener instalada la herramienta Make.
- Tener los archivos de entrada necesarios para iniciar el juego.

## Compilación y ejecución

Desde la carpeta del proyecto, compilar con:

```bash
make
```

Luego ejecutar:

```bash
./pvz
```
## Instrucciones de Juego

Las instrucciones de juego vienen incluidas al ejecutar, dentro del menu de juego donde podrá jugar, leer las instrucciones o salir del juego.
