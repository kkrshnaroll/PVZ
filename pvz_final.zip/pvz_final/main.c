
#include <stdio.h>
#include <stdlib.h>
#include <raylib.h>
#include <time.h>

#include "configuracion.h"
#include "jardin.h"
#include "plantas.h"
#include "zombies.h"
#include "juego.h"
#include "visualizacion/tarea3_visualizacion.h"
#include "estructuras.h"


// Agrega un sol reutilizando espacios libres del arreglo.
static void agregarSol(Partida *partida, float x, float y, int valor) {
    for (int i = 0; i < MAX_SOLES; i++) {
        if (!partida->solesJardin[i].activo) {
            partida->solesJardin[i].x = x;
            partida->solesJardin[i].y = y;
            partida->solesJardin[i].valor = valor;
            partida->solesJardin[i].activo = 1;

            if (i >= partida->cantidadSoles) {
                partida->cantidadSoles = i + 1;
            }
            return;
        }
    }
}

// Comprueba si el clic se hizo sobre un sol y lo recoge.
static void recogerSoles(Partida *partida) {
    if (!IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
        return;
    }

    Vector2 mouse = GetMousePosition();

    for (int i = 0; i < partida->cantidadSoles; i++) {
        if (partida->solesJardin[i].activo) {
            float dx = mouse.x - partida->solesJardin[i].x;
            float dy = mouse.y - partida->solesJardin[i].y;

            if (dx * dx + dy * dy <= 22.0f * 22.0f) {
                partida->soles += partida->solesJardin[i].valor;
                partida->solesJardin[i].activo = 0;

                printf("Recogiste %d soles. Total: %d\\n",
                       partida->solesJardin[i].valor, partida->soles);
            }
        }
    }
}

// Genera soles de girasoles y soles aleatorios usando contadores seguros.
static void actualizarGeneracionSoles(
    Partida *partida,
    const Configuracion *config
) {
    int intervaloGirasol = 5;
    int valorGirasol = 25;
    int intervaloAleatorio = (int)(config->frecuenciaBaseSoles + 0.5f);

    // Usa los valores definidos para el girasol en configuracion.txt.
    for (int i = 0; i < config->cantidadPlantas; i++) {
        if (config->plantas[i].tipo == PLANTA_GIRASOL) {
            if (config->plantas[i].frecuenciaGeneracion > 0) {
                intervaloGirasol =
                    (int)(config->plantas[i].frecuenciaGeneracion + 0.5f);
            }
            if (config->plantas[i].solesGenerados > 0) {
                valorGirasol = config->plantas[i].solesGenerados;
            }
            break;
        }
    }

    if (intervaloGirasol < 1) intervaloGirasol = 1;
    if (intervaloAleatorio < 1) intervaloAleatorio = 1;

    for (int fila = 0; fila < partida->filas; fila++) {
        for (int columna = 0; columna < partida->columnas; columna++) {
            if (partida->jardin[fila][columna] == CELDA_GIRASOL) {
            }
        }
    }

    // El contador siempre vuelve a un rango válido, incluso si no hay girasoles.
    partida->contadorGirasoles++;
    if (partida->contadorGirasoles >= intervaloGirasol) {
        partida->contadorGirasoles = 0;

        for (int fila = 0; fila < partida->filas; fila++) {
            for (int columna = 0; columna < partida->columnas; columna++) {
                if (partida->jardin[fila][columna] == CELDA_GIRASOL) {
                    float x = 170 + columna * 80 + 40;
                    float y = 150 + fila * 80 + 18;
                    agregarSol(partida, x, y, valorGirasol);
                }
            }
        }
    }

    // Los soles aleatorios aparecen en posiciones distintas del tablero.
    partida->contadorSolesAleatorios++;
    if (partida->contadorSolesAleatorios >= intervaloAleatorio) {
        partida->contadorSolesAleatorios = 0;

        float x = 170 + 18 + (float)(rand() % (partida->columnas * 80 - 36));
        float y = 150 + 18 + (float)(rand() % (partida->filas * 80 - 36));
        agregarSol(partida, x, y, valorGirasol);
    }
}


// Reinicia el estado de la partida para comenzar desde el menu o jugar otra vez.
static void reiniciarPartida(
    Partida *partida,
    Configuracion *config,
    int **contadoresAtaque
) {
    for (int f = 0; f < partida->filas; f++) {
        for (int c = 0; c < partida->columnas; c++) {
            partida->jardin[f][c] = CELDA_VACIA;
            contadoresAtaque[f][c] = 0;
        }
        partida->cortacesped[f] = 1;
    }

    for (int i = 0; i < partida->capacidadZombies; i++) {
        partida->zombies[i].activo = 0;
        partida->zombies[i].contadorAtaque = 0;
        partida->zombies[i].contadorComida = 0;
        partida->zombies[i].contadorMovimiento = 0;
    }

    for (int i = 0; i < MAX_SOLES; i++) {
        partida->solesJardin[i].activo = 0;
    }

    partida->cantidadSoles = 0;
    partida->contadorSolesAleatorios = 0;
    partida->contadorGirasoles = 0;
    partida->soles = config->solesIniciales;
    partida->oleadaActual = 1;
    partida->zombiesPorOleada = config->zombiesPrimeraOleada;
    partida->cantidadZombies = 0;
    partida->zombiesGenerados = 0;
    partida->turno = 1;
    partida->juegoTerminado = 0;

    reiniciarElementosVisuales();
}

// Inicializa el juego y controla el flujo entre menú, instrucciones, partida, resultado y cierre.
int main(void) {

    srand(time(NULL));

    // Cargamos la configuracion del juego.
    Configuracion config = {0};

    if (!cargarConfiguracion(&config, "configuracion.txt")) {
        printf("Error al cargar la configuracion\n");
        return 1;
    }

    // Creamos e inicializamos la partida.
    Partida partida = {0};

    // Cargamos el jardin dinamicamente.
    partida.jardin = leerJardin(
        "jardin.txt",
        &partida.filas,
        &partida.columnas
    );

    if (partida.jardin == NULL) {
        printf("Error al cargar el jardin\n");
        liberarConfiguracion(&config);
        return 1;
    }

    int filas = partida.filas;
    int columnas = partida.columnas;

    // Creamos una matriz para los contadores de ataque.
    int **contadoresAtaque = crearJardin(&filas, &columnas);

    if (contadoresAtaque == NULL) {
        printf("Error al crear los contadores de ataque\n");
        liberarJardin(partida.jardin, &filas);
        liberarConfiguracion(&config);
        return 1;
    }

    // Calculamos la capacidad necesaria para la oleada mas grande.
    int capacidadZombies = config.zombiesPrimeraOleada +
        (config.cantidadOleadas - 1) * config.incrementoZombies;

    if (capacidadZombies <= 0) {
        printf("Error: capacidad de zombies no valida\n");
        liberarJardin(contadoresAtaque, &filas);
        liberarJardin(partida.jardin, &filas);
        liberarConfiguracion(&config);
        return 1;
    }

    // Guardamos la capacidad y reservamos memoria para los zombies.
    partida.capacidadZombies = capacidadZombies;
    partida.zombies = malloc(partida.capacidadZombies * sizeof(Zombie));

    if (partida.zombies == NULL) {
        printf("Error al reservar memoria para los zombies\n");
        liberarJardin(contadoresAtaque, &filas);
        liberarJardin(partida.jardin, &filas);
        liberarConfiguracion(&config);
        return 1;
    }

    // Reservamos memoria para los cortacespedes.
    partida.cortacesped = malloc(filas * sizeof(int));

    if (partida.cortacesped == NULL) {
        printf("Error al reservar memoria para los cortacespedes\n");
        free(partida.zombies);
        liberarJardin(contadoresAtaque, &filas);
        liberarJardin(partida.jardin, &filas);
        liberarConfiguracion(&config);
        return 1;
    }

    // Inicializamos los cortacespedes.
    for (int i = 0; i < filas; i++) {
        partida.cortacesped[i] = 1;
    }

    // Inicializamos los valores iniciales de la partida.
    partida.soles = config.solesIniciales;

    partida.oleadaActual = 1;
    partida.zombiesPorOleada = config.zombiesPrimeraOleada;
    partida.cantidadZombies = 0;
    partida.zombiesGenerados = 0;

    partida.turno = 1;
    partida.contadorGirasoles = 0;
    partida.juegoTerminado = 0;
    //variables para el entretiempo entre oleadas
    int entreOleadas = 0;
    float tiempoInicipEntreOleadas = 0;




    // Abrimos la ventana del juego.
    iniciarVisualizacion();

    // Inicializamos el audio y cargamos la musica y los sonidos.
    InitAudioDevice();

    Music musicaJuego = LoadMusicStream(
        "visualizacion/recursos/sonidos/musica_juego.wav"
    );
    musicaJuego.looping = true;

    Sound sonidoVictoria = LoadSound(
        "visualizacion/recursos/sonidos/victoria.wav"
    );
    Sound sonidoDerrota = LoadSound(
        "visualizacion/recursos/sonidos/derrota.wav"
    );

    // Evita reproducir varias veces el sonido del resultado.
    int sonidoResultadoReproducido = 0;

    printf("El juego comenzo\n");

    //tiempo de preparacion inicial
    int preparacionInicial = 1;
    float tiempoInicioPreparacion = GetTime();

    float tiempoAnterior = GetTime();

    // 0 = menu principal, 1 = instrucciones, 2 = partida.
    int pantallaActual = 0;

    printf("Esperando en el menu principal\n");

    // Bucle principal.
    while (!debeCerrarVisualizacion()) {

        // Menu e instrucciones se muestran antes de iniciar la partida.
        if (pantallaActual == 0 || pantallaActual == 1) {
            comenzarFrameVisualizacion();

            int accionMenu = 0;
            if (pantallaActual == 0) {
                accionMenu = dibujarMenuPrincipal();
            } else {
                accionMenu = dibujarInstrucciones();
            }

            terminarFrameVisualizacion();

            if (pantallaActual == 0) {
                if (accionMenu == 1) {
                    reiniciarPartida(&partida, &config, contadoresAtaque);
                    preparacionInicial = 1;
                    tiempoInicioPreparacion = GetTime();
                    tiempoAnterior = GetTime();
                    entreOleadas = 0;
                    sonidoResultadoReproducido = 0;
                    StopSound(sonidoVictoria);
                    StopSound(sonidoDerrota);
                    StopMusicStream(musicaJuego);
                    PlayMusicStream(musicaJuego);
                    pantallaActual = 2;
                } else if (accionMenu == 2) {
                    pantallaActual = 1;
                } else if (accionMenu == 3) {
                    break;
                }
            } else if (accionMenu == 1) {
                pantallaActual = 0;
            }

            continue;
        }

        // Mantiene actualizada la musica en bucle.
        if (partida.juegoTerminado == 0) {
            UpdateMusicStream(musicaJuego);
        }

        // Al terminar la partida, cambiamos a un unico sonido de resultado.
        if (partida.juegoTerminado == 1 &&
            sonidoResultadoReproducido == 0) {

            StopMusicStream(musicaJuego);

            int gano = (partida.oleadaActual >= config.cantidadOleadas &&
                        partida.zombiesGenerados >= partida.zombiesPorOleada);

            // La misma condicion visual de victoria: ultima oleada sin zombies activos.
            int zombiesActivosResultado = 0;
            for (int i = 0; i < partida.cantidadZombies; i++) {
                if (partida.zombies[i].activo == 1) {
                    zombiesActivosResultado++;
                }
            }
            gano = (partida.oleadaActual >= config.cantidadOleadas &&
                    zombiesActivosResultado == 0 &&
                    partida.zombiesGenerados >= partida.zombiesPorOleada);

            if (gano) {
                PlaySound(sonidoVictoria);
            } else {
                PlaySound(sonidoDerrota);
            }

            sonidoResultadoReproducido = 1;
        }
        // Comprobamos si termino la preparacion inicial.
        if (preparacionInicial == 1 &&
            GetTime() - tiempoInicioPreparacion >= config.tiempoPreparacion) {

            preparacionInicial = 0;

            // Generamos la primera oleada.
            generarOleadas(
                partida.jardin,
                partida.zombies,
                &partida.cantidadZombies,
                &partida.zombiesGenerados,
                partida.zombiesPorOleada,
                partida.capacidadZombies,
                filas,
                columnas,
                config.zombies,
                config.cantidadZombies
            );

            tiempoAnterior = GetTime();

            printf("¡Comienza la primera oleada!\n");
        }

        // Actualizamos el juego cada segundo.
        if (GetTime() - tiempoAnterior >= 1.0f &&
            partida.juegoTerminado == 0 && entreOleadas ==0 &&
            preparacionInicial == 0) {

            printf("\nTurno %d:\n", partida.turno);

            // Actualizamos el turno.
            actualizarTurno(
                partida.jardin,
                partida.zombies,
                partida.cantidadZombies,
                &partida.soles,
                &partida.contadorGirasoles,
                &partida.juegoTerminado,
                partida.cortacesped,
                filas,
                columnas,
                contadoresAtaque,
                partida.oleadaActual
            );

            // Actualizamos la generacion de soles coleccionables.
            actualizarGeneracionSoles(&partida, &config);

            // Generamos un zombie si queda alguno pendiente.
            if (partida.zombiesGenerados < partida.zombiesPorOleada) {

                generarOleadas(
                    partida.jardin,
                    partida.zombies,
                    &partida.cantidadZombies,
                    &partida.zombiesGenerados,
                    partida.zombiesPorOleada,
                    partida.capacidadZombies,
                    filas,
                    columnas,
                    config.zombies,
                    config.cantidadZombies
                );
            }

            // Contamos los zombies que siguen activos.
            int zombiesActivos = 0;

            for (int i = 0; i < partida.cantidadZombies; i++) {

                if (partida.zombies[i].activo == 1) {
                    zombiesActivos++;
                }
            }

            printf("Zombies activos: %d\n", zombiesActivos);

            // Comprobamos si termino la oleada.
        if (zombiesActivos == 0 &&
            partida.zombiesGenerados == partida.zombiesPorOleada &&
            partida.juegoTerminado == 0) {

         if (partida.oleadaActual < config.cantidadOleadas) {

        // Comenzamos el entretiempo.
        entreOleadas = 1;
        tiempoInicipEntreOleadas = GetTime();

        printf("Oleada completada. Tiempo para preparar el jardin.\n");

    } else {

        printf("FELICIDADES! GANASTE EL JUEGO\n");
        partida.juegoTerminado = 1;
    }
}

            // Imprimimos la matriz actualizada.
            imprimirMatriz(
                partida.jardin,
                &filas,
                &columnas
            );

            // Actualizamos el tiempo y el turno.
            tiempoAnterior = GetTime();
            partida.turno++;
        }
        // Comprobamos si termino el entretiempo.
if (entreOleadas == 1 &&
    GetTime() - tiempoInicipEntreOleadas >= config.tiempoDescanso) {

    entreOleadas = 0;

    partida.oleadaActual++;

    partida.zombiesPorOleada += config.incrementoZombies;

    // Reiniciamos el contador para la nueva oleada.
    partida.cantidadZombies = 0;
    partida.zombiesGenerados = 0;

    printf("Comienza la oleada %d con %d zombies\n",
           partida.oleadaActual,
           partida.zombiesPorOleada);

    tiempoAnterior = GetTime();
}

    int tiempoRestantePreparacion = 0;

    if (partida.juegoTerminado == 0) {
    // Recoger soles con clic antes de procesar la compra de plantas.
    recogerSoles(&partida);

    actualizarSeleccionTienda();

    // Detectamos si se hizo clic en una casilla.
    int filaClic;
    int columnaClic;

    if (obtenerCasillaClickeada(&filaClic, &columnaClic)) {

        int seleccion = obtenerPlantaSeleccionada();

        if (seleccion >= 0) {

            int precios[] = {50, 100, 150, 125, 175, 200};

            int tiposPlanta[] = {
                CELDA_GIRASOL,
                CELDA_LANZAGUISANTES,
                CELDA_NUEZ,
                CELDA_GATOESPINOSO,
                CELDA_LANZAGUISANTESFUEGO,
                CELDA_NUEZREFORZADA
            };

            // Comprobamos que haya suficientes soles.
            if (partida.soles >= precios[seleccion]) {

                // Comprobamos que la casilla este vacia.
                if (partida.jardin[filaClic][columnaClic] == CELDA_VACIA) {

                    partida.soles -= precios[seleccion];

                    partida.jardin[filaClic][columnaClic] =
                        tiposPlanta[seleccion];

                    limpiarSeleccionTienda();

                }
            }
        }
    }

    // Calculamos los segundos que quedan de preparación inicial o de descanso
    // entre oleadas. Si no hay una pausa activa, el contador permanece en cero.
    if (preparacionInicial == 1) {

        float transcurrido = GetTime() - tiempoInicioPreparacion;

        tiempoRestantePreparacion =
            (int)(config.tiempoPreparacion - transcurrido + 0.999f);

    }
    else if (entreOleadas == 1) {

        float transcurrido = GetTime() - tiempoInicipEntreOleadas;

        tiempoRestantePreparacion =
            (int)(config.tiempoDescanso - transcurrido + 0.999f);

    }

    } // Fin de la interacción: la partida ya terminó.

    // Contamos los zombies que siguen activos para mostrar el estado de la oleada
    // y determinar si se cumplieron las condiciones de victoria.
    int zombiesActivosUI = 0;
    for (int i = 0; i < partida.cantidadZombies; i++) {
        if (partida.zombies[i].activo == 1) zombiesActivosUI++;
    }

    // Calculamos cuántos zombies todavía faltan por generar en esta oleada.
    // Evitamos que el contador visual muestre un número negativo.
    int zombiesPendientesUI = partida.zombiesPorOleada - partida.zombiesGenerados;
    if (zombiesPendientesUI < 0) zombiesPendientesUI = 0;

    // Iniciamos el dibujo del frame actual de Raylib.
    comenzarFrameVisualizacion();

    // Dibujamos primero el terreno y la decoración que sirven de fondo.
    dibujarTerreno();
    dibujarDecoracion();

    // Mostramos la tienda y el contador de soles disponibles.
    dibujarTienda(partida.soles, tiempoRestantePreparacion);

    // Actualizamos las posiciones y colisiones visuales de los proyectiles.
    actualizarProyectiles(partida.zombies, partida.cantidadZombies);

    // Dibujamos las plantas colocadas en el jardín.
    dibujarPlantas(
        partida.jardin,
        filas,
        columnas
    );

    // Dibujamos los soles que están disponibles para recoger.
    dibujarSoles(partida.solesJardin, partida.cantidadSoles);

    // Dibujamos los zombies que participan en la partida.
    dibujarZombies(
        partida.zombies,
        partida.cantidadZombies
    );

    // Añadimos los elementos decorativos y las podadoras de cada fila.
    dibujarArbusto();
    dibujarCortacespedes(partida.cortacesped, filas);

    // Mostramos la información de la partida: oleada, zombies y temporizador.
    dibujarEstadoPartida(
        partida.oleadaActual, config.cantidadOleadas,
        zombiesActivosUI, zombiesPendientesUI, tiempoRestantePreparacion,
        preparacionInicial, entreOleadas
    );

    // Dibujamos los proyectiles al final para que queden visibles sobre el jardín.
    dibujarProyectiles();

    // Si la partida terminó, determinamos si fue una victoria o una derrota
    // y mostramos la pantalla de resultado para recibir la acción de la jugadora.
    int accionResultado = 0;
    if (partida.juegoTerminado == 1) {
        int gano = (partida.oleadaActual >= config.cantidadOleadas &&
                    zombiesActivosUI == 0 && zombiesPendientesUI == 0);
        accionResultado = dibujarResultadoPartida(gano);
    }

    // Finalizamos el frame y presentamos en pantalla todo lo dibujado.
    terminarFrameVisualizacion();

    if (accionResultado == 1) {
        // Jugar de nuevo: se reinicia todo y vuelve la musica de partida.
        reiniciarPartida(&partida, &config, contadoresAtaque);
        preparacionInicial = 1;
        tiempoInicioPreparacion = GetTime();
        tiempoAnterior = GetTime();
        entreOleadas = 0;
        sonidoResultadoReproducido = 0;
        StopSound(sonidoVictoria);
        StopSound(sonidoDerrota);
        StopMusicStream(musicaJuego);
        PlayMusicStream(musicaJuego);
    } else if (accionResultado == 2) {
        // Volver al menu principal.
        StopMusicStream(musicaJuego);
        pantallaActual = 0;
    } else if (accionResultado == 3) {
        break;
    }
   
}
    

    // Liberamos los recursos de audio.
    StopMusicStream(musicaJuego);
    UnloadMusicStream(musicaJuego);
    UnloadSound(sonidoVictoria);
    UnloadSound(sonidoDerrota);
    CloseAudioDevice();

    // Cerramos la ventana del juego.
    cerrarVisualizacion();

    // Liberamos la memoria dinamica.
    free(partida.cortacesped);
    free(partida.zombies);

    liberarJardin(contadoresAtaque, &filas);
    liberarJardin(partida.jardin, &filas);
    liberarConfiguracion(&config);

    return 0;
}
